from django.contrib import admin
from .models import Usuario, TipoTecnico, Tecnico

admin.site.register(Usuario)
admin.site.register(TipoTecnico)
admin.site.register(Tecnico)
